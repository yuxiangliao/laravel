<h1><?php echo e($name); ?></h1>
<h3>当前时间是 <?php echo e(date('Y-m-d H:i:s')); ?></h3>