<h1>{{$name}}</h1>
<h3>当前时间是 {{date('Y-m-d H:i:s')}}</h3>