@extends('layouts.home')

@section('content')
    @parent
<div class="middle">我是layouts区域的替换内容 XXXXXXXX</div>
@endsection

