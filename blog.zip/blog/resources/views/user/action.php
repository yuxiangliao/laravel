<?php
/**
 * Created by liao.
 * User: liao
 * Date: 2018-03-25
 * Time: 12:02
 */
?>
<h1><?=$name?></h1>
<h2><?=$action?></h2>
<h3><?=print_r($all)?></h3>
