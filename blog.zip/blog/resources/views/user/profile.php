<?php
/**
 * Created by liao.
 * User: liao
 * Date: 2018-03-25
 * Time: 10:46
 */

?>

<p>
    hello,<?=$username?>
</p>
