<?php

throw new \Exception('boo');
