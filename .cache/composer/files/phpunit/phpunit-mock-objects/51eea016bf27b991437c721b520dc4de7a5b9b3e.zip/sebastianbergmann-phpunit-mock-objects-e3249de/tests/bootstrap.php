<?php
require __DIR__ . '/_fixture/FunctionCallback.php';
require __DIR__ . '/../vendor/autoload.php';
